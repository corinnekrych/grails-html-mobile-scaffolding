includeTargets << grailsScript("_GrailsInit")

target(main: "generate one HTML view with different section for CRUD") {
  event 'GenerateHtmlView', ['Generating HTML view for domain class...']
}

setDefaultTarget(main)

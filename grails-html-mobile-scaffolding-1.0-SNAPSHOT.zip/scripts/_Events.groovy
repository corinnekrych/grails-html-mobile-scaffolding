

//eventInstallTemplatesStart = { 
//  println "InstallTemplate::DEBUG $it"
//}
//
//eventStatusUpdate = {
//  println "InstallStatusupdate::DEBUG $it"
//  includeTargets << new File("${htmlMobileScaffoldingPluginDir}/scripts/_InstallHtmlMobileTemplates.groovy")
//  htmlMobileCopyTemplates()
//}